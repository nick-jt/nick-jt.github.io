#!/usr/bin/env bash

INPUT="tesfornick.tif"
OUTPUT="testfornick.mp4"
FPS=30

# First, extract all frames from the multi-page TIFF
convert $INPUT -scene 1 frame_%03d.png

# Then create the video from the frame sequence
ffmpeg -y -framerate $FPS -pattern_type glob -i 'frame_*.png' \
  -vf "pad=ceil(iw/2)*2:ceil(ih/2)*2" \
  -c:v libx264 -pix_fmt yuv420p -movflags +faststart \
  $OUTPUT

# Clean up temporary frames
rm frame_*.png