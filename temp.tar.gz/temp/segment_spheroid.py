#!/usr/bin/env python3
"""
SAM-2 Spheroid Segmentation Script
Segments spheroid across frames in a multi-page TIFF and tracks pixel count over time.

Usage:
    python segment_spheroid.py <input.tif> [--visualize] [--output <dir>]

Examples:
    python segment_spheroid.py tesfornick.tif
    python segment_spheroid.py tesfornick.tif --visualize
    python segment_spheroid.py data/spheroid.tif --visualize --output results/
"""

import os
import sys
import argparse
import numpy as np
from PIL import Image
import matplotlib

matplotlib.use("Agg")  # Use non-interactive backend
import matplotlib.pyplot as plt
from pathlib import Path

import cv2

# Don't check for SAM-2 at import time to avoid directory shadowing issues
# We'll check when we actually need it
SAM2_AVAILABLE = None  # Will be checked lazily


def check_sam2_available():
    """Lazy check for SAM-2 availability."""
    global SAM2_AVAILABLE
    if SAM2_AVAILABLE is not None:
        return SAM2_AVAILABLE

    try:
        # Try importing from installed package
        import sys

        # Remove current directory from path temporarily to avoid shadowing
        original_path = sys.path.copy()
        sys.path = [p for p in sys.path if not p.startswith(os.getcwd())]

        from sam2.build_sam import build_sam2_video_predictor

        SAM2_AVAILABLE = True

        # Restore path
        sys.path = original_path
        return True
    except (ImportError, RuntimeError):
        SAM2_AVAILABLE = False
        return False


def load_multipage_tiff(tiff_path):
    """Load all frames from a multi-page TIFF file."""
    print(f"Loading TIFF from: {tiff_path}")

    img = Image.open(tiff_path)
    frames = []

    try:
        frame_idx = 0
        while True:
            img.seek(frame_idx)
            # Convert to RGB numpy array
            frame = np.array(img.convert("RGB"))
            frames.append(frame)
            frame_idx += 1
    except EOFError:
        pass  # End of frames

    print(f"Loaded {len(frames)} frames from TIFF")
    return frames


def setup_video_directory(frames, output_dir="temp_frames"):
    """
    SAM-2 video predictor expects frames in a directory.
    Save frames temporarily.
    """
    os.makedirs(output_dir, exist_ok=True)

    for idx, frame in enumerate(frames):
        frame_path = os.path.join(output_dir, f"{idx:05d}.jpg")
        cv2.imwrite(frame_path, cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))

    print(f"Saved {len(frames)} frames to {output_dir}/")
    return output_dir


def segment_spheroid_sam2(
    frames, checkpoint_path, model_cfg="configs/sam2/sam2_hiera_s.yaml"
):
    """
    Segment spheroid using SAM-2 video predictor.

    Args:
        frames: List of frame arrays
        checkpoint_path: Path to SAM-2 checkpoint
        model_cfg: Model configuration

    Returns:
        masks: List of binary masks for each frame
    """
    # Import SAM-2 inside function to avoid directory shadowing at module import
    import sys

    original_path = sys.path.copy()
    sys.path = [p for p in sys.path if not p.startswith(os.getcwd())]

    from sam2.build_sam import build_sam2_video_predictor

    sys.path = original_path

    # Setup temporary directory for frames
    frame_dir = setup_video_directory(frames)

    # Initialize SAM-2 video predictor
    print("Initializing SAM-2 video predictor...")
    predictor = build_sam2_video_predictor(model_cfg, checkpoint_path)

    # Initialize inference state
    inference_state = predictor.init_state(video_path=frame_dir)

    # Get frame dimensions
    height, width = frames[0].shape[:2]

    # Use center of first frame as prompt
    print(f"Using center point ({width // 2}, {height // 2}) as prompt on frame 0")

    frame_idx = 0
    point = np.array([[width // 2, height // 2]], dtype=np.float32)
    label = np.array([1], dtype=np.int32)  # 1 = foreground point

    # Add point prompt to first frame
    _, out_obj_ids, out_mask_logits = predictor.add_new_points(
        inference_state=inference_state,
        frame_idx=frame_idx,
        obj_id=1,
        points=point,
        labels=label,
    )

    # Propagate masks to all frames
    print("Propagating segmentation across all frames...")
    masks = []

    for frame_idx, obj_ids, mask_logits in predictor.propagate_in_video(
        inference_state
    ):
        # Get mask for object ID 1
        mask = (mask_logits[0] > 0.0).cpu().numpy()
        mask = mask.squeeze()
        masks.append(mask)

    # Clean up temporary directory
    import shutil

    shutil.rmtree(frame_dir)
    print(f"Cleaned up temporary directory: {frame_dir}")

    return masks


def segment_spheroid_automatic(frames):
    """
    Automatic segmentation using simple thresholding.
    Fallback method when SAM-2 is not available.
    """
    print("Using automatic thresholding segmentation")
    masks = []

    for idx, frame in enumerate(frames):
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)

        # Apply Otsu's thresholding
        _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Morphological operations to clean up mask
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        # Find largest connected component (assume that's the spheroid)
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
            mask, connectivity=8
        )

        if num_labels > 1:
            # Get largest component (excluding background)
            largest_component = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
            mask = (labels == largest_component).astype(np.uint8) * 255

        masks.append(mask > 0)

    return masks


def count_pixels_over_time(masks):
    """Count number of pixels in each mask."""
    pixel_counts = [np.sum(mask) for mask in masks]
    return pixel_counts


def save_results(pixel_counts, output_dir, tiff_basename):
    """Save pixel counts to CSV and create a plot."""

    os.makedirs(output_dir, exist_ok=True)

    output_csv = os.path.join(output_dir, f"{tiff_basename}_pixel_counts.csv")
    output_plot = os.path.join(output_dir, f"{tiff_basename}_pixel_counts.png")

    # Save to CSV
    with open(output_csv, "w") as f:
        f.write("Frame,Time_Frame,Pixel_Count\n")
        for idx, count in enumerate(pixel_counts):
            f.write(f"{idx},{idx},{count}\n")

    print(f"Saved pixel counts to: {output_csv}")

    # Create plot
    fig, ax = plt.subplots(figsize=(10, 6))
    frames = list(range(len(pixel_counts)))

    ax.plot(frames, pixel_counts, "b-", linewidth=2, marker="o", markersize=4)
    ax.set_xlabel("Frame Number (Time)", fontsize=12)
    ax.set_ylabel("Masked Pixel Count", fontsize=12)
    ax.set_title("Spheroid Size Over Time", fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3)

    # Add statistics
    mean_count = np.mean(pixel_counts)
    ax.axhline(
        y=mean_count,
        color="r",
        linestyle="--",
        alpha=0.5,
        label=f"Mean: {mean_count:.0f}",
    )
    ax.legend()

    plt.tight_layout()
    plt.savefig(output_plot, dpi=150, bbox_inches="tight")
    print(f"Saved plot to: {output_plot}")
    plt.close()


def visualize_segmentation_batches(
    frames, masks, output_dir, tiff_basename, frames_per_batch=10
):
    """
    Visualize segmentation on frames in batches.

    Args:
        frames: List of frame arrays
        masks: List of binary masks
        output_dir: Directory to save visualizations
        tiff_basename: Base name for output files
        frames_per_batch: Number of frames to show per visualization file
    """
    n_frames = len(frames)
    n_batches = int(np.ceil(n_frames / frames_per_batch))

    print(
        f"Creating {n_batches} visualization files ({frames_per_batch} frames each)..."
    )

    for batch_idx in range(n_batches):
        start_idx = batch_idx * frames_per_batch
        end_idx = min(start_idx + frames_per_batch, n_frames)
        batch_size = end_idx - start_idx

        # Create figure with two rows
        fig, axes = plt.subplots(2, batch_size, figsize=(3 * batch_size, 6))

        # Handle case where batch_size is 1
        if batch_size == 1:
            axes = axes.reshape(2, 1)

        for col_idx, frame_idx in enumerate(range(start_idx, end_idx)):
            # First row: Original frame
            axes[0, col_idx].imshow(frames[frame_idx])
            axes[0, col_idx].set_title(f"Frame {frame_idx}", fontsize=10)
            axes[0, col_idx].axis("off")

            # Second row: Original frame with mask overlay
            mask_overlay = np.zeros_like(frames[frame_idx])
            mask_overlay[masks[frame_idx]] = [255, 0, 0]  # Red overlay

            axes[1, col_idx].imshow(frames[frame_idx])
            axes[1, col_idx].imshow(mask_overlay, alpha=0.4)
            axes[1, col_idx].set_title(
                f"{np.sum(masks[frame_idx])} pixels", fontsize=10
            )
            axes[1, col_idx].axis("off")

        plt.tight_layout()

        # Save with batch range in filename
        output_file = os.path.join(
            output_dir, f"{tiff_basename}_visualization_{start_idx + 1}to{end_idx}.png"
        )
        plt.savefig(output_file, dpi=150, bbox_inches="tight")
        print(f"  Saved: {output_file}")
        plt.close()


def main():
    parser = argparse.ArgumentParser(
        description="Segment spheroid in multi-page TIFF using SAM-2",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python segment_spheroid.py tesfornick.tif
  python segment_spheroid.py tesfornick.tif --visualize
  python segment_spheroid.py data/spheroid.tif --visualize --output results/
        """,
    )

    parser.add_argument("input_tif", help="Input multi-page TIFF file")
    parser.add_argument(
        "--visualize",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate visualization images (10 frames per image) (default: True)",
    )
    parser.add_argument(
        "--output", default="output", help="Output directory (default: output/)"
    )
    parser.add_argument(
        "--checkpoint",
        default="sam2_checkpoints/sam2_hiera_small.pt",
        help="Path to SAM-2 checkpoint",
    )
    parser.add_argument(
        "--config",
        default="configs/sam2/sam2_hiera_s.yaml",
        help="Path to SAM-2 config file",
    )

    args = parser.parse_args()

    # Check if input file exists
    if not os.path.exists(args.input_tif):
        print(f"ERROR: Input file not found: {args.input_tif}")
        sys.exit(1)

    # Get basename for output files
    tiff_basename = Path(args.input_tif).stem

    # Load frames
    frames = load_multipage_tiff(args.input_tif)

    if len(frames) == 0:
        print("ERROR: No frames loaded from TIFF!")
        sys.exit(1)

    # Segment spheroid
    sam2_available = check_sam2_available()

    if sam2_available and os.path.exists(args.checkpoint):
        print(f"\nUsing SAM-2 checkpoint: {args.checkpoint}")
        masks = segment_spheroid_sam2(frames, args.checkpoint, args.config)
    else:
        if not sam2_available:
            print("\nWARNING: SAM-2 not available. Using automatic thresholding.")
        elif not os.path.exists(args.checkpoint):
            print(f"\nWARNING: SAM-2 checkpoint not found: {args.checkpoint}")
            print("Using automatic thresholding as fallback.")
        print("")
        masks = segment_spheroid_automatic(frames)

    # Count pixels
    print("\nCounting pixels in masks...")
    pixel_counts = count_pixels_over_time(masks)

    # Save results
    print("\nSaving results...")
    save_results(pixel_counts, args.output, tiff_basename)

    # Visualize segmentation if requested
    if args.visualize:
        print("\nCreating visualizations...")
        visualize_segmentation_batches(frames, masks, args.output, tiff_basename)

    print("\n" + "=" * 60)
    print("ANALYSIS COMPLETE!")
    print("=" * 60)
    print(f"Total frames processed: {len(frames)}")
    print(f"Pixel count range: {min(pixel_counts)} - {max(pixel_counts)}")
    print(f"Mean pixel count: {np.mean(pixel_counts):.0f}")
    print(f"Std deviation: {np.std(pixel_counts):.0f}")
    print(f"\nOutput directory: {args.output}/")
    print("=" * 60)


if __name__ == "__main__":
    main()
