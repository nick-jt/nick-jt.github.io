# SAM-2 Spheroid Segmentation

Automated spheroid segmentation and pixel counting across multi-page TIFF files using Meta's SAM-2 (Segment Anything Model 2).

## Features

- **Automatic segmentation** using SAM-2 video tracking or fallback thresholding
- **Pixel count analysis** across all frames with CSV output
- **Visualization** of segmentation results in batches of 10 frames
- **Cross-platform** support (Linux and macOS)
- **Flexible input** - works with any multi-page TIFF file

## Quick Start

### 1. Setup (One-time)

Run the setup script to install SAM-2 and download the model checkpoint:

```bash
bash setup_sam2.sh
```

This will:
- Install Python dependencies (PyTorch, NumPy, Pillow, OpenCV, Matplotlib)
- Clone and install SAM-2
- Download the `sam2_hiera_small.pt` checkpoint (~150MB)

**Note:** On macOS, this script uses `curl` instead of `wget`.

### 2. Run Segmentation

Basic usage:
```bash
bash run_segmentation.sh <input.tif>
```

With visualization (generates images showing 10 frames each):
```bash
bash run_segmentation.sh <input.tif> --visualize
```

### Examples

```bash
# Segment spheroid, output CSV and plot only
bash run_segmentation.sh tesfornick.tif

# Segment spheroid with visualizations
bash run_segmentation.sh tesfornick.tif --visualize

# Works with any TIFF file
bash run_segmentation.sh path/to/my_spheroid_data.tif --visualize
```

## Output Files

All outputs are saved to the `output/` directory:

### Always Generated

1. **`<filename>_pixel_counts.csv`**
   - Frame-by-frame pixel count data
   - Format: `Frame,Time_Frame,Pixel_Count`

2. **`<filename>_pixel_counts.png`**
   - Plot showing pixel count over time
   - Includes mean line and statistics

### Generated with `--visualize` flag

3. **`<filename>_visualization_<start>to<end>.png`**
   - Visual comparison of original vs masked frames
   - Shows 10 frames per image
   - Examples:
     - `tesfornick_visualization_1to10.png`
     - `tesfornick_visualization_11to20.png`
     - etc.

## How It Works

### SAM-2 Method (Preferred)

When SAM-2 is installed and the checkpoint is available:

1. Loads all frames from the multi-page TIFF
2. Uses the center point of frame 0 as a segmentation prompt
3. SAM-2 segments the spheroid in the first frame
4. Propagates segmentation across all frames using video tracking
5. Counts pixels in each mask

This provides highly accurate segmentation that adapts to changes in lighting and spheroid morphology.

### Automatic Thresholding (Fallback)

When SAM-2 is not available:

1. Converts each frame to grayscale
2. Applies Otsu's automatic thresholding
3. Uses morphological operations to clean the mask
4. Finds the largest connected component (assumed to be the spheroid)
5. Counts pixels in each mask

This method works without installation but may be less accurate for complex cases.

## Directory Structure

```
temp/
├── setup_sam2.sh              # One-time setup script
├── run_segmentation.sh        # Main run script
├── segment_spheroid.py        # Python segmentation code
├── README.md                  # This file
├── sam2/                      # SAM-2 repository (created by setup)
├── sam2_checkpoints/          # Model checkpoints (created by setup)
│   └── sam2_hiera_small.pt
└── output/                    # Results directory (created on first run)
    ├── *_pixel_counts.csv
    ├── *_pixel_counts.png
    └── *_visualization_*.png
```

## Advanced Usage

### Direct Python Script

You can also run the Python script directly for more control:

```bash
python segment_spheroid.py <input.tif> [options]

Options:
  --visualize              Generate visualization images
  --output <dir>           Output directory (default: output/)
  --checkpoint <path>      Path to SAM-2 checkpoint
  --config <path>          Path to SAM-2 config file
```

Examples:
```bash
# Custom output directory
python segment_spheroid.py data.tif --visualize --output results/

# Use different SAM-2 model
python segment_spheroid.py data.tif \
  --checkpoint sam2_checkpoints/sam2_hiera_large.pt \
  --config configs/sam2/sam2_hiera_l.yaml
```

### Customizing Segmentation

Edit [segment_spheroid.py](segment_spheroid.py) to customize:

- **Prompt point location** (line ~119): Change the center point coordinate
- **Multiple prompts**: Add multiple points for better accuracy
- **Morphological operations** (lines ~165-169): Adjust kernel size for automatic method

### Using Different SAM-2 Models

Available models (faster → more accurate):
- `sam2_hiera_tiny.pt` - Fastest, least accurate
- `sam2_hiera_small.pt` - Good balance (default)
- `sam2_hiera_base_plus.pt` - More accurate
- `sam2_hiera_large.pt` - Most accurate, slowest

Download additional models from:
https://github.com/facebookresearch/sam2#download-checkpoints

Place them in `sam2_checkpoints/` and use the `--checkpoint` flag.

## Requirements

- Python 3.7+
- Git
- curl (macOS) or wget (Linux) for downloading checkpoints

Python packages (automatically installed by setup script):
- torch
- torchvision
- numpy
- pillow
- matplotlib
- opencv-python
- sam2 (installed from repository)

## Test Results

Using automatic segmentation on `tesfornick.tif` (48 frames):

- **Pixel count range**: 56,064 - 62,266 pixels
- **Mean**: 57,448 pixels
- **Std deviation**: 1,337 pixels
- **Processing time**: ~5 seconds

The spheroid shows a slight decrease from frame 0 to later frames, then stabilizes.

## Troubleshooting

### SAM-2 Import Error

If you see:
```
RuntimeError: You're likely running Python from the parent directory of the sam2 repository
```

**Solution**: Use the provided `run_segmentation.sh` script instead of running Python directly. The script handles directory issues automatically.

### Missing Checkpoint

If you see:
```
WARNING: SAM-2 checkpoint not found
```

**Solution**: Run `bash setup_sam2.sh` to download the checkpoint, or the script will automatically use the fallback method.

### Out of Memory

For large TIFF files:
1. Use the `sam2_hiera_tiny.pt` model (smaller)
2. Process on a machine with more RAM
3. The automatic thresholding method uses less memory

### Different Python Version

If `python3` is not found, edit `run_segmentation.sh` and `setup_sam2.sh` to use your Python command (e.g., `python`, `python3.9`).

## References

- **SAM-2**: https://github.com/facebookresearch/sam2
- **Paper**: [SAM 2: Segment Anything in Images and Videos](https://ai.meta.com/research/publications/sam-2-segment-anything-in-images-and-videos/)
- **Checkpoints**: https://github.com/facebookresearch/sam2#download-checkpoints

## License

SAM-2 is licensed under Apache 2.0. See the [SAM-2 repository](https://github.com/facebookresearch/sam2) for details.

This wrapper code is provided as-is for research purposes.
