#!/usr/bin/env bash
#
# SAM-2 Setup Script
# Compatible with Linux and macOS
#

set -e  # Exit on error

echo "=========================================="
echo "SAM-2 Installation Script"
echo "=========================================="
echo ""

# Detect OS
OS="$(uname -s)"
case "$OS" in
    Linux*)     MACHINE=Linux;;
    Darwin*)    MACHINE=Mac;;
    *)          MACHINE="UNKNOWN:${OS}"
esac
echo "Detected OS: $MACHINE"
echo ""

# Check Python
if ! command -v python &> /dev/null && ! command -v python3 &> /dev/null; then
    echo "ERROR: Python not found. Please install Python 3.7+."
    exit 1
fi

PYTHON_CMD=$(command -v python3 || command -v python)
echo "Using Python: $PYTHON_CMD ($($PYTHON_CMD --version))"
echo ""

# Install dependencies
echo "Step 1: Installing Python dependencies..."
echo ""

$PYTHON_CMD -m pip install --upgrade pip --quiet
$PYTHON_CMD -m pip install torch torchvision numpy pillow matplotlib opencv-python --quiet

# Clone and install SAM-2
echo ""
echo "Step 2: Installing SAM-2..."
echo ""

# Remove old sam2 directory if it exists and is causing issues
if [ -d "sam2" ]; then
    echo "Found existing sam2 directory. Removing to ensure clean install..."
    rm -rf sam2
fi

echo "Cloning SAM-2 repository..."
git clone https://github.com/facebookresearch/sam2.git

# Create a separate directory for checkpoints outside the sam2 repo
echo "Creating checkpoints directory..."
mkdir -p sam2_checkpoints

# Install SAM-2 package
echo "Installing SAM-2 package..."
cd sam2
$PYTHON_CMD -m pip install -e . --quiet
cd ..

echo ""
echo "Step 3: Downloading SAM-2 checkpoint..."
echo ""

cd sam2_checkpoints

if [ ! -f "sam2_hiera_small.pt" ]; then
    echo "Downloading sam2_hiera_small.pt (~150MB)..."

    # Use curl on Mac, wget on Linux
    if [ "$MACHINE" = "Mac" ]; then
        if command -v curl &> /dev/null; then
            curl -L -o sam2_hiera_small.pt https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_small.pt
        else
            echo "ERROR: curl not found. Please install curl or download the checkpoint manually."
            exit 1
        fi
    else
        if command -v wget &> /dev/null; then
            wget https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_small.pt
        elif command -v curl &> /dev/null; then
            curl -L -o sam2_hiera_small.pt https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_small.pt
        else
            echo "ERROR: Neither wget nor curl found. Please install one or download the checkpoint manually."
            exit 1
        fi
    fi
else
    echo "Checkpoint already exists, skipping download..."
fi

cd ..

# Verify installation
echo ""
echo "Step 4: Verifying installation..."
echo ""

$PYTHON_CMD -c "import sam2; print('SAM-2 successfully installed!')" || {
    echo "WARNING: SAM-2 import failed. The package may not be installed correctly."
    echo "You can still use the automatic segmentation fallback method."
}

echo ""
echo "=========================================="
echo "Installation Complete!"
echo "=========================================="
echo ""
echo "Directory structure:"
echo "  sam2/              - SAM-2 repository (package installed via pip)"
echo "  sam2_checkpoints/  - Model checkpoints"
echo ""
echo "To run the segmentation:"
echo "  bash run_segmentation.sh <input.tif> [--visualize]"
echo ""
echo "Examples:"
echo "  bash run_segmentation.sh tesfornick.tif"
echo "  bash run_segmentation.sh tesfornick.tif --visualize"
echo ""
